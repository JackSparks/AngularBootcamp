import { DateFormControl } from './date-form-control';

describe('DateFormControl', () => {
  it('should create an instance', () => {
    expect(new DateFormControl()).toBeTruthy();
  });
});
